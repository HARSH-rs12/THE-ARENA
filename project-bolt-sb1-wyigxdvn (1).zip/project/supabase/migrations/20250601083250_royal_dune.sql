/*
  # Add exam column to study_materials table

  1. Changes
    - Add required 'exam' column to study_materials table
    - Set default value to prevent issues with existing records
    - Add check constraint to ensure valid exam values

  2. Security
    - Maintains existing RLS policies
*/

ALTER TABLE study_materials 
ADD COLUMN exam text NOT NULL DEFAULT 'UPSC CSE';

-- Add check constraint to ensure only valid exam values are allowed
ALTER TABLE study_materials
ADD CONSTRAINT study_materials_exam_check
CHECK (exam IN ('UPSC CSE', 'GATE CSE', 'JEE', 'NEET'));