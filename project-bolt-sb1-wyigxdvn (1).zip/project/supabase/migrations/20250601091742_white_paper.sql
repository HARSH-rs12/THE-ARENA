-- Drop the existing constraint
ALTER TABLE study_materials DROP CONSTRAINT study_materials_exam_check;

-- Add updated constraint with all exam values
ALTER TABLE study_materials
ADD CONSTRAINT study_materials_exam_check
CHECK (exam IN (
  'JEE Main', 'JEE Advanced', 'GATE', 'ESE',
  'NDA', 'CDS', 'AFCAT', 'CAPF',
  'UPSC CSE', 'State PSC', 'SSC CGL', 'SSC CHSL',
  'IBPS PO', 'SBI PO', 'RBI Grade B', 'NABARD',
  'UGC NET', 'CTET', 'State TET', 'CSIR NET'
));