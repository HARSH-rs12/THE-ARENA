/*
  # Create comprehensive study materials table

  1. New Tables
    - `study_materials`
      - `id` (uuid, primary key)
      - `title` (text)
      - `author` (text)
      - `category` (text)
      - `url` (text)
      - `type` (text)
      - `description` (text)
      - `rating` (numeric)
      - `downloads` (integer)
      - `exam` (text)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on `study_materials` table
    - Add policy for public read access

  3. Sample Data
    - Comprehensive study materials for all exam categories
    - Books, notes, and mock tests for each exam type
*/

CREATE TABLE IF NOT EXISTS study_materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  author text NOT NULL,
  category text NOT NULL,
  url text NOT NULL,
  type text NOT NULL CHECK (type IN ('book', 'notes', 'mock')),
  description text NOT NULL,
  rating numeric NOT NULL CHECK (rating >= 0 AND rating <= 5),
  downloads integer NOT NULL DEFAULT 0,
  exam text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE study_materials ENABLE ROW LEVEL SECURITY;

-- Allow public read access
CREATE POLICY "Allow public read access"
  ON study_materials
  FOR SELECT
  TO public
  USING (true);

-- Insert comprehensive study materials for all exams
INSERT INTO study_materials (title, author, category, url, type, description, rating, downloads, exam) VALUES

-- JEE Main Materials
('Concepts of Physics Vol 1', 'HC Verma', 'Physics', 'https://drive.google.com/file/d/1PJqzHwqwBvuYJ9KhIpnZvnDyIh1jI8F9/view', 'book', 'A comprehensive guide covering fundamental physics concepts with detailed explanations and solved examples.', 4.8, 15000, 'JEE Main'),
('Concepts of Physics Vol 2', 'HC Verma', 'Physics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Advanced physics concepts with a focus on electricity, magnetism, and modern physics.', 4.7, 12000, 'JEE Main'),
('Problems in Physics', 'IE Irodov', 'Physics', 'https://drive.google.com/file/d/1PKqzHwqwBvuYJ9KhIpnZvnDyIh1jI8F9/view', 'book', 'Advanced problem-solving book with challenging physics problems for JEE preparation.', 4.9, 18000, 'JEE Main'),
('Advanced Problems in Physical Chemistry', 'MS Chauhan', 'Chemistry', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive collection of advanced chemistry problems with detailed solutions.', 4.6, 13000, 'JEE Main'),
('Physical Chemistry', 'N Awasthi', 'Chemistry', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete physical chemistry guide with theory and practice problems.', 4.7, 14000, 'JEE Main'),
('Calculus for JEE', 'Cengage', 'Mathematics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'In-depth coverage of calculus topics with JEE-focused problems and solutions.', 4.8, 16000, 'JEE Main'),
('JEE Main Mock Test Series 2024', 'Allen Institute', 'Mock Tests', 'https://www.allen.ac.in/jee-main-mock-test', 'mock', 'Comprehensive mock test series with detailed analysis and performance tracking.', 4.7, 25000, 'JEE Main'),
('Physics Topper Notes 2023', 'JEE Advanced Rank 1', 'Physics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'notes', 'Concise physics notes covering all important topics and formulas.', 4.9, 20000, 'JEE Main'),

-- JEE Advanced Materials
('Advanced Physics Problems', 'DC Pandey', 'Physics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Advanced level physics problems for JEE Advanced preparation.', 4.8, 14000, 'JEE Advanced'),
('Advanced Chemistry', 'JD Lee', 'Chemistry', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive inorganic chemistry for advanced level preparation.', 4.7, 12000, 'JEE Advanced'),
('JEE Advanced Mock Tests', 'FIITJEE', 'Mock Tests', 'https://www.fiitjee.com/jee-advanced-mock-test', 'mock', 'High-quality mock tests designed by IIT faculty members.', 4.8, 18000, 'JEE Advanced'),

-- GATE Materials
('GATE Computer Science', 'Made Easy Publications', 'Computer Science', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete GATE CS preparation with theory and practice questions.', 4.6, 22000, 'GATE'),
('GATE Mechanical Engineering', 'GK Publications', 'Mechanical', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive mechanical engineering guide for GATE preparation.', 4.5, 19000, 'GATE'),
('GATE Mock Test Series', 'GATE Academy', 'Mock Tests', 'https://www.gateacademy.co.in/mock-tests', 'mock', 'Subject-wise and full-length mock tests for all GATE branches.', 4.7, 30000, 'GATE'),

-- ESE Materials
('ESE Preliminary Exam', 'Made Easy', 'General Studies', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete guide for ESE preliminary examination.', 4.4, 15000, 'ESE'),
('ESE Mains Engineering', 'IES Master', 'Engineering', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Detailed coverage of engineering subjects for ESE mains.', 4.6, 12000, 'ESE'),

-- NDA Materials
('NDA Mathematics', 'Arihant Publications', 'Mathematics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete mathematics guide for NDA examination.', 4.5, 18000, 'NDA'),
('NDA General Ability Test', 'Pathfinder Publications', 'General Knowledge', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive GAT preparation with current affairs and general knowledge.', 4.4, 16000, 'NDA'),
('NDA Mock Test Series', 'Major Kalshi Classes', 'Mock Tests', 'https://www.majorkalshiclasses.com/nda-mock-tests', 'mock', 'Complete mock test series with SSB interview preparation.', 4.6, 20000, 'NDA'),

-- CDS Materials
('CDS English & General Knowledge', 'Arihant', 'English', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete English and GK guide for CDS examination.', 4.3, 14000, 'CDS'),
('CDS Elementary Mathematics', 'R.S. Aggarwal', 'Mathematics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Elementary mathematics concepts and practice problems.', 4.5, 15000, 'CDS'),

-- AFCAT Materials
('AFCAT Complete Guide', 'Disha Publications', 'General Awareness', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete AFCAT preparation guide with practice papers.', 4.4, 12000, 'AFCAT'),
('AFCAT Mock Tests', 'Cavalier India', 'Mock Tests', 'https://www.cavalierindia.com/afcat-mock-tests', 'mock', 'Online mock tests with detailed analysis and performance tracking.', 4.5, 16000, 'AFCAT'),

-- CAPF Materials
('CAPF Assistant Commandant', 'Arihant', 'General Studies', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete guide for CAPF AC examination.', 4.3, 10000, 'CAPF'),

-- UPSC CSE Materials
('Indian Polity', 'M. Laxmikanth', 'Polity', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive guide to Indian polity and governance.', 4.9, 50000, 'UPSC CSE'),
('Indian Economy', 'Ramesh Singh', 'Economics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete coverage of Indian economy for UPSC preparation.', 4.8, 45000, 'UPSC CSE'),
('Modern History of India', 'Bipin Chandra', 'History', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Detailed account of modern Indian history.', 4.7, 40000, 'UPSC CSE'),
('Geography of India', 'Majid Husain', 'Geography', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive geography guide for UPSC preparation.', 4.6, 35000, 'UPSC CSE'),
('UPSC Prelims Mock Tests', 'Vision IAS', 'Mock Tests', 'https://www.visionias.in/upsc-prelims-mock-tests', 'mock', 'High-quality prelims mock tests with detailed explanations.', 4.8, 60000, 'UPSC CSE'),
('UPSC Mains Test Series', 'Insights IAS', 'Mock Tests', 'https://www.insightsonindia.com/mains-test-series', 'mock', 'Comprehensive mains test series with answer writing practice.', 4.7, 45000, 'UPSC CSE'),

-- State PSC Materials
('State PSC General Studies', 'Lucent Publications', 'General Studies', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete general studies guide for state PSC examinations.', 4.4, 25000, 'State PSC'),

-- SSC CGL Materials
('SSC CGL Quantitative Aptitude', 'Kiran Publications', 'Mathematics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete quantitative aptitude guide for SSC CGL.', 4.5, 30000, 'SSC CGL'),
('SSC CGL Reasoning', 'R.S. Aggarwal', 'Reasoning', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive reasoning guide with practice questions.', 4.4, 28000, 'SSC CGL'),
('SSC CGL Mock Tests', 'Adda247', 'Mock Tests', 'https://www.adda247.com/ssc-cgl-mock-tests', 'mock', 'Complete mock test series for all tiers of SSC CGL.', 4.6, 40000, 'SSC CGL'),

-- SSC CHSL Materials
('SSC CHSL Complete Guide', 'Disha Publications', 'General Studies', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete preparation guide for SSC CHSL examination.', 4.3, 22000, 'SSC CHSL'),

-- Banking Materials
('IBPS PO Complete Guide', 'Arihant', 'Banking', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive guide for IBPS PO examination.', 4.5, 35000, 'IBPS PO'),
('SBI PO Practice Sets', 'Kiran Publications', 'Banking', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Practice sets and previous year papers for SBI PO.', 4.4, 32000, 'SBI PO'),
('Banking Mock Tests', 'Testbook', 'Mock Tests', 'https://testbook.com/banking-mock-tests', 'mock', 'Comprehensive mock tests for all banking examinations.', 4.6, 50000, 'IBPS PO'),
('RBI Grade B Study Material', 'Made Easy', 'Economics', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Specialized study material for RBI Grade B examination.', 4.7, 18000, 'RBI Grade B'),
('NABARD Grade A Guide', 'Arihant', 'Agriculture', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete guide for NABARD Grade A examination.', 4.4, 12000, 'NABARD'),

-- Teaching Materials
('UGC NET Paper 1', 'Trueman Publications', 'Teaching Aptitude', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete guide for UGC NET Paper 1 preparation.', 4.5, 28000, 'UGC NET'),
('CTET Complete Guide', 'Arihant', 'Child Development', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Comprehensive CTET preparation guide.', 4.4, 25000, 'CTET'),
('State TET Practice Papers', 'Disha Publications', 'Teaching', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Practice papers for various state TET examinations.', 4.3, 20000, 'State TET'),
('CSIR NET Life Sciences', 'Disha Publications', 'Life Sciences', 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view', 'book', 'Complete guide for CSIR NET Life Sciences.', 4.6, 15000, 'CSIR NET'),
('Teaching Mock Tests', 'Gradeup', 'Mock Tests', 'https://gradeup.co/teaching-mock-tests', 'mock', 'Mock tests for all teaching examinations including CTET, UGC NET.', 4.5, 35000, 'CTET');