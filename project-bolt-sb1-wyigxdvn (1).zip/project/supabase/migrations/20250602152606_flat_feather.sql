/*
  # Add gamification and user profile tables

  1. New Tables
    - user_profiles: Stores user preferences and progress
    - challenges: Daily/weekly/monthly challenges
    - study_sessions: Track study time and focus
    - test_results: Store test attempts and analysis
    - study_groups: Manage group study sessions
    - current_affairs: News feed for relevant exams
    
  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- User Profiles Table
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  exam_type text NOT NULL,
  goal_year integer NOT NULL,
  daily_study_hours integer NOT NULL,
  language text NOT NULL,
  mission_name text NOT NULL,
  strengths text[] NOT NULL,
  weaknesses text[] NOT NULL,
  avatar jsonb NOT NULL,
  stats jsonb NOT NULL,
  rewards jsonb NOT NULL,
  preferences jsonb NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Challenges Table
CREATE TABLE IF NOT EXISTS challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  title text NOT NULL,
  description text NOT NULL,
  type text NOT NULL CHECK (type IN ('daily', 'weekly', 'monthly')),
  reward jsonb NOT NULL,
  progress integer DEFAULT 0,
  completed boolean DEFAULT false,
  deadline timestamptz NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Study Sessions Table
CREATE TABLE IF NOT EXISTS study_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  type text NOT NULL CHECK (type IN ('pomodoro', 'regular')),
  subject text NOT NULL,
  topic text NOT NULL,
  duration integer NOT NULL,
  start_time timestamptz NOT NULL,
  end_time timestamptz,
  breaks integer DEFAULT 0,
  focus_score integer,
  notes text[],
  created_at timestamptz DEFAULT now()
);

-- Test Results Table
CREATE TABLE IF NOT EXISTS test_results (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES auth.users(id),
  type text NOT NULL CHECK (type IN ('topic', 'mock', 'previous-year')),
  subject text NOT NULL,
  topics text[] NOT NULL,
  score numeric NOT NULL,
  max_score numeric NOT NULL,
  time_spent integer NOT NULL,
  accuracy numeric NOT NULL,
  speed numeric NOT NULL,
  rank integer,
  weak_topics text[],
  strong_topics text[],
  mistakes jsonb,
  created_at timestamptz DEFAULT now()
);

-- Study Groups Table
CREATE TABLE IF NOT EXISTS study_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  exam text NOT NULL,
  members uuid[] NOT NULL,
  leader uuid REFERENCES auth.users(id),
  schedule jsonb NOT NULL,
  topics text[] NOT NULL,
  messages jsonb DEFAULT '[]'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Current Affairs Table
CREATE TABLE IF NOT EXISTS current_affairs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  content text NOT NULL,
  category text NOT NULL,
  source text NOT NULL,
  url text NOT NULL,
  date date NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE test_results ENABLE ROW LEVEL SECURITY;
ALTER TABLE study_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE current_affairs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can read own profile"
  ON user_profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can update own profile"
  ON user_profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can read own challenges"
  ON challenges FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own challenges"
  ON challenges FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own challenges"
  ON challenges FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can read own study sessions"
  ON study_sessions FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create study sessions"
  ON study_sessions FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read own test results"
  ON test_results FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create test results"
  ON test_results FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read their study groups"
  ON study_groups FOR SELECT
  TO authenticated
  USING (auth.uid() = ANY(members));

CREATE POLICY "Users can create study groups"
  ON study_groups FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = leader);

CREATE POLICY "Group members can update their groups"
  ON study_groups FOR UPDATE
  TO authenticated
  USING (auth.uid() = ANY(members));

CREATE POLICY "Everyone can read current affairs"
  ON current_affairs FOR SELECT
  TO authenticated
  USING (true);

-- Indexes
CREATE INDEX user_profiles_exam_type_idx ON user_profiles(exam_type);
CREATE INDEX challenges_user_id_type_idx ON challenges(user_id, type);
CREATE INDEX study_sessions_user_id_date_idx ON study_sessions(user_id, start_time);
CREATE INDEX test_results_user_id_date_idx ON test_results(user_id, created_at);
CREATE INDEX study_groups_exam_idx ON study_groups(exam);
CREATE INDEX current_affairs_category_date_idx ON current_affairs(category, date);