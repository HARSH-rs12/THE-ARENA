export interface ExamProfile {
  examType: string;
  goalYear: number;
  dailyStudyHours: number;
  language: 'English' | 'Hindi';
  missionName: string;
  strengths: string[];
  weaknesses: string[];
  avatar: {
    type: string;
    accessories: string[];
    level: number;
  };
  stats: {
    streak: number;
    totalStudyHours: number;
    testsCompleted: number;
    questionsAttempted: number;
    accuracy: number;
    xp: number;
    rank: number;
  };
  rewards: {
    badges: string[];
    unlockedFeatures: string[];
    customRewards: Array<{
      name: string;
      condition: string;
      achieved: boolean;
    }>;
  };
  preferences: {
    notifications: boolean;
    soundEffects: boolean;
    darkMode: boolean;
    language: string;
  };
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'weekly' | 'monthly';
  reward: {
    xp: number;
    badge?: string;
  };
  progress: number;
  completed: boolean;
  deadline: Date;
}

export interface StudySession {
  id: string;
  type: 'pomodoro' | 'regular';
  subject: string;
  topic: string;
  duration: number;
  startTime: Date;
  endTime?: Date;
  breaks: number;
  focusScore: number;
  notes: string[];
}

export interface Mistake {
  id: string;
  question: string;
  subject: string;
  topic: string;
  subtopic: string;
  difficulty: 'easy' | 'medium' | 'hard';
  tags: string[];
  solution: string;
  revisionCount: number;
  lastRevised: Date;
  nextRevision: Date;
  confidence: number;
}

export interface TestResult {
  id: string;
  type: 'topic' | 'mock' | 'previous-year';
  subject: string;
  topics: string[];
  score: number;
  maxScore: number;
  timeSpent: number;
  accuracy: number;
  speed: number;
  rank?: number;
  weakTopics: string[];
  strongTopics: string[];
  mistakes: Mistake[];
  date: Date;
}

export interface DailyMission {
  id: string;
  title: string;
  type: 'study' | 'test' | 'revision' | 'challenge';
  description: string;
  reward: {
    xp: number;
    streak: number;
  };
  completed: boolean;
  deadline: Date;
}

export interface StudyGroup {
  id: string;
  name: string;
  exam: string;
  members: string[];
  leader: string;
  schedule: {
    day: string;
    time: string;
    duration: number;
  }[];
  topics: string[];
  messages: Array<{
    id: string;
    sender: string;
    content: string;
    timestamp: Date;
  }>;
}