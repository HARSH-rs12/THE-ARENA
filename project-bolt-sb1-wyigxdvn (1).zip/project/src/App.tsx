import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { ArenaApp } from '@/components/arena/ArenaApp';

function App() {
  return (
    <ThemeProvider defaultTheme="dark">
      <ArenaApp />
      <Toaster />
    </ThemeProvider>
  );
}

export default App;