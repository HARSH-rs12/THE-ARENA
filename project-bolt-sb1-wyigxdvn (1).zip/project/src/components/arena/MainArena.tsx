import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Header } from './Header';
import { SyllabusTracker } from './SyllabusTracker';
import { StatsPanel } from './StatsPanel';
import { TodayGoals } from './TodayGoals';
import { PracticeArena } from './PracticeArena';
import { Books } from './Books';
import { DoubtSection } from './DoubtSection';
import { ScrollArea } from '@/components/ui/scroll-area';

interface MainArenaProps {
  selectedExam: string;
  onBack?: () => void;
}

export function MainArena({ selectedExam, onBack }: MainArenaProps) {
  const [activeTab, setActiveTab] = useState("dashboard");
  
  return (
    <div className="h-screen flex flex-col overflow-hidden">
      <Header selectedExam={selectedExam} onBack={onBack} showBackButton={!!onBack} />
      
      <div className="flex-1 container mx-auto py-4 overflow-hidden flex flex-col">
        <Tabs 
          defaultValue="dashboard" 
          className="w-full flex-1 flex flex-col overflow-hidden"
          onValueChange={(value) => setActiveTab(value)}
        >
          <TabsList className="grid grid-cols-6 mb-6">
            <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
            <TabsTrigger value="syllabus">Syllabus</TabsTrigger>
            <TabsTrigger value="practice">Practice</TabsTrigger>
            <TabsTrigger value="books">Books</TabsTrigger>
            <TabsTrigger value="doubts">Doubts</TabsTrigger>
            <TabsTrigger value="stats">Stats</TabsTrigger>
          </TabsList>
          
          <ScrollArea className="flex-1 overflow-auto">
            <TabsContent value="dashboard" className="space-y-6 mt-0 p-1">
              <div className="grid md:grid-cols-3 gap-6">
                <div className="md:col-span-2">
                  <TodayGoals selectedExam={selectedExam} />
                </div>
                <StatsPanel />
              </div>
              
              <SyllabusTracker 
                selectedExam={selectedExam}
                limit={3} 
                showViewAll={true} 
                onViewAll={() => setActiveTab("syllabus")} 
              />
            </TabsContent>
            
            <TabsContent value="syllabus" className="mt-0 p-1">
              <SyllabusTracker selectedExam={selectedExam} />
            </TabsContent>
            
            <TabsContent value="practice" className="mt-0 p-1">
              <PracticeArena selectedExam={selectedExam} />
            </TabsContent>

            <TabsContent value="books" className="mt-0 p-1">
              <Books selectedExam={selectedExam} />
            </TabsContent>

            <TabsContent value="doubts" className="mt-0 p-1">
              <DoubtSection selectedExam={selectedExam} />
            </TabsContent>
            
            <TabsContent value="stats" className="mt-0">
              <div className="rounded-lg border border-border bg-card p-6">
                <h3 className="text-2xl font-bold mb-4">Your Progress Statistics</h3>
                <p className="text-muted-foreground">
                  Detailed analytics and insights about your study progress.
                  (Coming soon)
                </p>
              </div>
            </TabsContent>
          </ScrollArea>
        </Tabs>
      </div>
      
      {/* Powered by footer */}
      <div className="text-xs text-muted-foreground text-center py-2 border-t">
        Powered by HrSSz & Co.
      </div>
    </div>
  );
}