import { CalendarClock, Award, BarChart3, Flame } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer } from 'recharts';

const subjectData = [
  { name: 'Physics', value: 75, color: '#3b82f6' },
  { name: 'Chemistry', value: 42, color: '#22c55e' },
  { name: 'Mathematics', value: 63, color: '#f97316' },
];

const weeklyProgress = [
  { day: 'Mon', hours: 4 },
  { day: 'Tue', hours: 3.5 },
  { day: 'Wed', hours: 5 },
  { day: 'Thu', hours: 2 },
  { day: 'Fri', hours: 4.5 },
  { day: 'Sat', hours: 6 },
  { day: 'Sun', hours: 3 },
];

export function StatsPanel() {
  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-xl font-bold">Your Stats</CardTitle>
        <CardDescription>Track your studying metrics</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-2">
          <div className="flex justify-between">
            <div className="flex items-center gap-2">
              <CalendarClock className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm font-medium">Study Streak</span>
            </div>
            <span className="text-sm font-bold">3 days</span>
          </div>
          <Progress value={60} className="h-2" />
          <p className="text-xs text-muted-foreground">Study today to maintain your streak!</p>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between">
            <div className="flex items-center gap-2">
              <Flame className="h-4 w-4 text-orange-500" />
              <span className="text-sm font-medium">Focus Time Today</span>
            </div>
            <span className="text-sm font-bold">45 min</span>
          </div>
          <Progress value={25} className="h-2" />
          <p className="text-xs text-muted-foreground">Daily Goal: 3 hours</p>
        </div>
        
        <div className="space-y-2">
          <div className="flex justify-between">
            <div className="flex items-center gap-2">
              <Award className="h-4 w-4 text-yellow-500" />
              <span className="text-sm font-medium">XP This Week</span>
            </div>
            <span className="text-sm font-bold">250 / 1000</span>
          </div>
          <Progress value={25} className="h-2" />
        </div>

        <div className="pt-4 space-y-6">
          <div>
            <h4 className="text-sm font-medium mb-3">Subject Progress</h4>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={subjectData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {subjectData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div>
            <h4 className="text-sm font-medium mb-3">Weekly Study Hours</h4>
            <div className="h-[200px]">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={weeklyProgress}>
                  <XAxis dataKey="day" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="hours" fill="#f97316" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}