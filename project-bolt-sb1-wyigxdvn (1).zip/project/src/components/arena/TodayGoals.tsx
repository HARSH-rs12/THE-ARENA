import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Button } from '@/components/ui/button';
import { Plus, Target, Trash2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { motion } from 'framer-motion';

interface Goal {
  id: string;
  text: string;
  completed: boolean;
  exam: string;
}

interface TodayGoalsProps {
  selectedExam: string;
}

export function TodayGoals({ selectedExam }: TodayGoalsProps) {
  const [goalInput, setGoalInput] = useState('');
  const [goals, setGoals] = useLocalStorage<Goal[]>('arena-today-goals', []);

  const addGoal = () => {
    if (!goalInput.trim()) return;
    
    const newGoal: Goal = {
      id: Date.now().toString(),
      text: goalInput,
      completed: false,
      exam: selectedExam
    };
    
    setGoals([...goals, newGoal]);
    setGoalInput('');
  };

  const toggleGoal = (id: string) => {
    setGoals(goals.map(goal => 
      goal.id === id ? { ...goal, completed: !goal.completed } : goal
    ));
  };

  const deleteGoal = (id: string) => {
    setGoals(goals.filter(goal => goal.id !== id));
  };

  const examGoals = goals.filter(goal => goal.exam === selectedExam);
  const completedCount = examGoals.filter(goal => goal.completed).length;
  const totalGoals = examGoals.length;
  const progressPercentage = totalGoals > 0 ? (completedCount / totalGoals) * 100 : 0;

  return (
    <Card>
      <CardHeader className="pb-3">
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl flex items-center gap-2">
              <Target className="h-5 w-5 text-orange-500" /> 
              Today's Battlefield
            </CardTitle>
            <CardDescription className="mt-1">
              Your mission objectives for {selectedExam}
            </CardDescription>
          </div>
          <Badge variant={progressPercentage === 100 ? "default" : "outline"}>
            {completedCount}/{totalGoals} Complete
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex gap-2">
            <Input 
              placeholder="Add a new goal..." 
              value={goalInput} 
              onChange={(e) => setGoalInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') addGoal();
              }}
              className="flex-1"
            />
            <Button onClick={addGoal} size="icon">
              <Plus className="h-4 w-4" />
            </Button>
          </div>
          
          <div className="space-y-2 mt-4">
            {examGoals.length === 0 ? (
              <div className="text-center py-6 text-muted-foreground">
                No goals set for today. Add some goals to get started!
              </div>
            ) : (
              examGoals.map((goal) => (
                <motion.div
                  key={goal.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, height: 0 }}
                  transition={{ duration: 0.2 }}
                  className="flex items-center justify-between space-x-2 p-3 border border-border rounded-md"
                >
                  <div className="flex items-center space-x-2">
                    <Checkbox 
                      id={`goal-${goal.id}`}
                      checked={goal.completed}
                      onCheckedChange={() => toggleGoal(goal.id)}
                    />
                    <Label 
                      htmlFor={`goal-${goal.id}`}
                      className={`text-sm ${goal.completed ? 'line-through text-muted-foreground' : ''}`}
                    >
                      {goal.text}
                    </Label>
                  </div>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={() => deleteGoal(goal.id)}
                    className="h-7 w-7 opacity-50 hover:opacity-100"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </motion.div>
              ))
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}