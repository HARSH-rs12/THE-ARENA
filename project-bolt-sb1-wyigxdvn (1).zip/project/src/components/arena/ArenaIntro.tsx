import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Crown, Shield, Sword, Sparkles } from 'lucide-react';

interface ArenaIntroProps {
  onSkip: () => void;
}

export function ArenaIntro({ onSkip }: ArenaIntroProps) {
  return (
    <AnimatePresence>
      <div className="h-screen w-full bg-black text-white flex items-center justify-center relative overflow-hidden">
        {/* Background Effects */}
        <motion.div 
          className="absolute inset-0 z-0"
          initial={{ scale: 1.5, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 2, ease: "easeOut" }}
        >
          <div 
            className="absolute inset-0 bg-cover bg-center"
            style={{
              backgroundImage: 'url("https://images.pexels.com/photos/1054218/pexels-photo-1054218.jpeg")',
              filter: 'brightness(0.3) saturate(1.5)'
            }}
          />
        </motion.div>

        {/* Dynamic Color Overlay */}
        <motion.div
          className="absolute inset-0 z-10"
          initial={{ opacity: 0 }}
          animate={{ 
            opacity: [0, 0.6, 0.3, 0.6, 0],
            background: [
              'radial-gradient(circle at 30% 50%, rgba(255,140,0,0.4) 0%, rgba(128,0,128,0.3) 50%, rgba(0,0,0,0) 100%)',
              'radial-gradient(circle at 70% 50%, rgba(255,69,0,0.5) 0%, rgba(75,0,130,0.4) 50%, rgba(0,0,0,0) 100%)',
              'radial-gradient(circle at 50% 50%, rgba(255,165,0,0.4) 0%, rgba(138,43,226,0.3) 50%, rgba(0,0,0,0) 100%)'
            ]
          }}
          transition={{ 
            duration: 4,
            repeat: Infinity,
            repeatType: "reverse",
            times: [0, 0.25, 0.5, 0.75, 1]
          }}
        />

        {/* Floating Elements */}
        <motion.div
          className="absolute w-full h-full pointer-events-none z-20"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 1 }}
        >
          {[...Array(20)].map((_, i) => (
            <motion.div
              key={i}
              className="absolute w-2 h-2 bg-orange-400 rounded-full"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
              }}
              animate={{
                y: [0, -30, 0],
                opacity: [0.3, 1, 0.3],
                scale: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 3 + Math.random() * 2,
                repeat: Infinity,
                delay: Math.random() * 2,
              }}
            />
          ))}
        </motion.div>

        {/* Text Content */}
        <motion.div 
          className="text-center max-w-xl px-4 relative z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 3 }}
        >
          <motion.div
            className="mb-8"
            initial={{ scale: 0, rotate: -180 }}
            animate={{ scale: 1, rotate: 0 }}
            transition={{ duration: 1.5, type: "spring", bounce: 0.4, delay: 4 }}
          >
            <motion.div
              className="w-32 h-32 mx-auto mb-6 relative"
              animate={{ 
                boxShadow: [
                  "0 0 40px rgba(255,140,0,0.5)",
                  "0 0 70px rgba(138,43,226,0.6)",
                  "0 0 40px rgba(255,140,0,0.5)"
                ]
              }}
              transition={{ duration: 2, repeat: Infinity }}
            >
              <div className="w-full h-full rounded-full border-4 border-orange-500 flex items-center justify-center bg-gradient-to-br from-orange-500/20 to-purple-500/20 backdrop-blur-sm">
                <motion.div
                  animate={{ 
                    rotate: [0, 360],
                    scale: [1, 1.1, 1]
                  }}
                  transition={{ 
                    rotate: { duration: 8, repeat: Infinity, ease: "linear" },
                    scale: { duration: 2, repeat: Infinity }
                  }}
                >
                  <Crown className="w-16 h-16 text-orange-400" />
                </motion.div>
                <motion.div
                  className="absolute top-2 right-2"
                  animate={{ rotate: [0, -360] }}
                  transition={{ duration: 6, repeat: Infinity, ease: "linear" }}
                >
                  <Shield className="w-6 h-6 text-purple-400" />
                </motion.div>
                <motion.div
                  className="absolute bottom-2 left-2"
                  animate={{ rotate: [0, 360] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "linear" }}
                >
                  <Sword className="w-6 h-6 text-red-400" />
                </motion.div>
                <motion.div
                  className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
                  animate={{ 
                    scale: [0.8, 1.2, 0.8],
                    opacity: [0.5, 1, 0.5]
                  }}
                  transition={{ duration: 3, repeat: Infinity }}
                >
                  <Sparkles className="w-8 h-8 text-yellow-400" />
                </motion.div>
              </div>
            </motion.div>
          </motion.div>

          <motion.h1 
            className="text-5xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-orange-500 via-purple-500 to-red-500"
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 5, duration: 0.8 }}
          >
            Where Warriors Rise
          </motion.h1>
          
          <motion.p 
            className="text-2xl mt-4 text-orange-300"
            initial={{ x: -50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 6, duration: 0.8 }}
          >
            Conquer Every Challenge
          </motion.p>
          
          <motion.p 
            className="text-2xl mt-2 text-orange-300"
            initial={{ x: 50, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 7, duration: 0.8 }}
          >
            Master Your Destiny
          </motion.p>
          
          <motion.h2 
            className="text-4xl font-bold mt-6 bg-clip-text text-transparent bg-gradient-to-r from-orange-400 via-purple-400 to-red-400"
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 8, duration: 0.8, type: "spring" }}
          >
            Dominate Your Future
          </motion.h2>
          
          <motion.h3 
            className="text-7xl font-extrabold mt-8 bg-clip-text text-transparent bg-gradient-to-r from-orange-500 via-purple-500 to-red-500"
            initial={{ opacity: 0, y: 30 }}
            animate={{ 
              opacity: 1, 
              y: 0,
              textShadow: [
                "0 0 40px rgba(255,140,0,0.5)",
                "0 0 70px rgba(138,43,226,0.6)",
                "0 0 40px rgba(255,140,0,0.5)"
              ]
            }}
            transition={{ 
              delay: 9, 
              duration: 1,
              textShadow: {
                duration: 2,
                repeat: Infinity,
                repeatType: "reverse"
              }
            }}
          >
            THE ARENA
          </motion.h3>
        </motion.div>

        {/* Skip Button */}
        <motion.div
          className="absolute bottom-8 right-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 2, duration: 0.5 }}
        >
          <Button 
            variant="ghost" 
            onClick={onSkip}
            className="text-white/70 hover:text-white hover:bg-white/10"
          >
            Skip Intro
          </Button>
        </motion.div>

        {/* Powered by */}
        <motion.div
          className="absolute bottom-4 left-4 text-xs text-white/50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 10, duration: 0.5 }}
        >
          Powered by HrSSz & Co.
        </motion.div>
      </div>
    </AnimatePresence>
  );
}