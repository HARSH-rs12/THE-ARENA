import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { syllabus as allSyllabi } from '@/data/syllabus';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { Trophy, Brain, Clock, Star, BookOpen, Sparkles, Target, CheckCircle2, XCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Progress } from '@/components/ui/progress';
import { useToast } from '@/hooks/use-toast';

interface Question {
  year: number;
  question: string;
  options: string[];
  correct: number;
  explanation?: string;
}

interface ChapterQuestions {
  [key: string]: {
    title: string;
    questions: Question[];
  };
}

// Comprehensive question bank for all exams
const examQuestions: { [exam: string]: ChapterQuestions } = {
  'JEE Main': {
    'Physics: Kinematics': {
      title: 'Physics: Kinematics',
      questions: [
        {
          year: 2024,
          question: 'A particle moves in a straight line with constant acceleration. If it covers 10m in the first second and 15m in the next second, what is its acceleration?',
          options: ['5 m/s²', '10 m/s²', '2.5 m/s²', '7.5 m/s²'],
          correct: 0,
          explanation: 'Using s = ut + ½at², for first second: 10 = u + ½a, for second interval: 15 = (u+a) + ½a. Solving: a = 5 m/s²'
        },
        {
          year: 2023,
          question: 'The velocity-time graph of a particle is a straight line making an angle θ with time axis. The displacement in time t is:',
          options: ['½(tan θ)t²', '(tan θ)t²', '½(tan θ)t', '(tan θ)t'],
          correct: 0,
          explanation: 'For constant acceleration a = tan θ, displacement s = ½at² = ½(tan θ)t²'
        }
      ]
    },
    'Chemistry: Atomic Structure': {
      title: 'Chemistry: Atomic Structure',
      questions: [
        {
          year: 2024,
          question: 'The maximum number of electrons that can be accommodated in the M shell is:',
          options: ['8', '18', '32', '50'],
          correct: 1,
          explanation: 'M shell has n=3, so maximum electrons = 2n² = 2(3)² = 18'
        }
      ]
    },
    'Math: Complex Numbers': {
      title: 'Math: Complex Numbers',
      questions: [
        {
          year: 2024,
          question: 'If z = 1 + i, then z⁴ equals:',
          options: ['-4', '4', '-4i', '4i'],
          correct: 0,
          explanation: 'z² = (1+i)² = 1 + 2i - 1 = 2i, z⁴ = (2i)² = -4'
        }
      ]
    }
  },
  'UPSC CSE': {
    'Indian Polity': {
      title: 'Indian Polity',
      questions: [
        {
          year: 2024,
          question: 'Which article of the Indian Constitution deals with the Fundamental Right to Freedom of Religion?',
          options: ['Article 25-28', 'Article 29-30', 'Article 32', 'Article 21'],
          correct: 0,
          explanation: 'Articles 25-28 of the Indian Constitution deal with the Right to Freedom of Religion. These articles ensure religious freedom for individuals and religious groups.'
        },
        {
          year: 2023,
          question: 'The concept of "Living Constitution" refers to:',
          options: [
            'Regular amendments to the Constitution',
            'Interpretation of Constitution in light of contemporary needs',
            'Written nature of Constitution',
            'Basic structure doctrine'
          ],
          correct: 1,
          explanation: 'Living Constitution refers to the dynamic interpretation of constitutional provisions to meet contemporary needs while preserving its basic principles.'
        }
      ]
    },
    'Indian Economy': {
      title: 'Indian Economy',
      questions: [
        {
          year: 2024,
          question: 'Which of the following is NOT a function of the Reserve Bank of India?',
          options: [
            'Monetary Policy formulation',
            'Foreign exchange management',
            'Credit rating of companies',
            'Banking sector regulation'
          ],
          correct: 2,
          explanation: 'Credit rating of companies is done by credit rating agencies like CRISIL, CARE, etc., not by RBI. RBI\'s main functions include monetary policy, forex management, and banking regulation.'
        }
      ]
    },
    'History: Ancient India': {
      title: 'History: Ancient India',
      questions: [
        {
          year: 2024,
          question: 'The Indus Valley Civilization was discovered in which year?',
          options: ['1920', '1921', '1922', '1924'],
          correct: 1,
          explanation: 'The Indus Valley Civilization was first discovered in 1921 by Dayaram Sahni at Harappa.'
        }
      ]
    }
  },
  'SSC CGL': {
    'Quantitative Aptitude: Percentages': {
      title: 'Quantitative Aptitude: Percentages',
      questions: [
        {
          year: 2024,
          question: 'If 20% of a number is 80, what is 25% of the same number?',
          options: ['100', '120', '80', '90'],
          correct: 0,
          explanation: 'If 20% of x = 80, then x = 400. Therefore, 25% of 400 = 100'
        }
      ]
    },
    'General Intelligence & Reasoning: Analogies': {
      title: 'General Intelligence & Reasoning: Analogies',
      questions: [
        {
          year: 2024,
          question: 'Book : Author :: Painting : ?',
          options: ['Canvas', 'Brush', 'Artist', 'Color'],
          correct: 2,
          explanation: 'Just as a book is created by an author, a painting is created by an artist.'
        }
      ]
    }
  },
  'GATE': {
    'Engineering Mathematics': {
      title: 'Engineering Mathematics',
      questions: [
        {
          year: 2024,
          question: 'The Laplace transform of e^(-at) is:',
          options: ['1/(s+a)', '1/(s-a)', 'a/(s+a)', 's/(s+a)'],
          correct: 0,
          explanation: 'The Laplace transform of e^(-at) is 1/(s+a) where s > -a'
        }
      ]
    }
  },
  'IBPS PO': {
    'Quantitative Aptitude: Simple Interest & Compound Interest': {
      title: 'Quantitative Aptitude: Simple Interest & Compound Interest',
      questions: [
        {
          year: 2024,
          question: 'What is the compound interest on Rs. 10,000 for 2 years at 10% per annum?',
          options: ['Rs. 2,000', 'Rs. 2,100', 'Rs. 2,200', 'Rs. 2,500'],
          correct: 1,
          explanation: 'CI = P[(1+r/100)^n - 1] = 10000[(1.1)² - 1] = 10000[1.21 - 1] = Rs. 2,100'
        }
      ]
    }
  },
  'NDA': {
    'Mathematics: Algebra': {
      title: 'Mathematics: Algebra',
      questions: [
        {
          year: 2024,
          question: 'If x + y = 10 and xy = 21, then x² + y² = ?',
          options: ['58', '62', '54', '50'],
          correct: 0,
          explanation: 'x² + y² = (x+y)² - 2xy = 10² - 2(21) = 100 - 42 = 58'
        }
      ]
    }
  },
  'UGC NET': {
    'Teaching Aptitude: Teaching Nature, Objectives, Characteristics': {
      title: 'Teaching Aptitude: Teaching Nature, Objectives, Characteristics',
      questions: [
        {
          year: 2024,
          question: 'Which of the following is NOT a characteristic of good teaching?',
          options: ['Clarity', 'Rigidity', 'Enthusiasm', 'Organization'],
          correct: 1,
          explanation: 'Good teaching should be flexible and adaptive, not rigid. Rigidity prevents effective learning.'
        }
      ]
    }
  }
};

interface PracticeArenaProps {
  selectedExam: string;
}

export function PracticeArena({ selectedExam }: PracticeArenaProps) {
  const [selectedChapter, setSelectedChapter] = useState('');
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showExplanation, setShowExplanation] = useState(false);
  const [practiceStats, setPracticeStats] = useLocalStorage('practice-stats', {
    questionsAttempted: 0,
    correctAnswers: 0,
    streak: 0,
    lastPracticeDate: null,
  });
  const { toast } = useToast();

  const examSyllabus = allSyllabi[selectedExam] || [];
  const currentExamQuestions = examQuestions[selectedExam] || {};

  const handleAnswerSubmit = (selectedIndex: number) => {
    setSelectedAnswer(selectedIndex);
    const isCorrect = selectedIndex === currentQuestion?.correct;
    
    const newStats = {
      ...practiceStats,
      questionsAttempted: practiceStats.questionsAttempted + 1,
      correctAnswers: practiceStats.correctAnswers + (isCorrect ? 1 : 0),
      streak: isCorrect ? practiceStats.streak + 1 : 0,
      lastPracticeDate: new Date().toISOString(),
    };
    
    setPracticeStats(newStats);
    
    toast({
      title: isCorrect ? "Correct! 🎉" : "Incorrect",
      description: isCorrect ? "Keep up the good work!" : "Don't worry, keep practicing!",
      variant: isCorrect ? "default" : "destructive",
    });
    
    setShowExplanation(true);
  };

  const nextQuestion = () => {
    if (currentChapter && currentQuestionIndex < currentChapter.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    }
  };

  const currentChapter = selectedChapter ? currentExamQuestions[selectedChapter] : null;
  const currentQuestion = currentChapter?.questions[currentQuestionIndex];
  const accuracy = practiceStats.questionsAttempted > 0 
    ? Math.round((practiceStats.correctAnswers / practiceStats.questionsAttempted) * 100) 
    : 0;

  // Get available chapters with questions
  const availableChapters = examSyllabus.filter(chapter => currentExamQuestions[chapter]);

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <Card className="col-span-2 bg-gradient-to-br from-orange-500/10 via-purple-500/10 to-pink-500/10">
          <CardHeader>
            <CardTitle className="text-2xl font-bold flex items-center gap-3">
              <Sparkles className="h-8 w-8 text-orange-500" />
              {selectedExam} Practice Arena
            </CardTitle>
            <CardDescription className="text-lg">
              Master your preparation with chapter-wise practice
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-3 gap-4">
              <Card className="bg-orange-500/10 border-orange-500/20">
                <CardHeader className="p-4">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Target className="h-5 w-5 text-orange-500" />
                    Questions Attempted
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-3xl font-bold text-orange-500">
                    {practiceStats.questionsAttempted}
                  </div>
                  <Progress value={practiceStats.questionsAttempted % 100} className="mt-2" />
                </CardContent>
              </Card>
              
              <Card className="bg-purple-500/10 border-purple-500/20">
                <CardHeader className="p-4">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Brain className="h-5 w-5 text-purple-500" />
                    Accuracy
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-3xl font-bold text-purple-500">{accuracy}%</div>
                  <Progress value={accuracy} className="mt-2" />
                </CardContent>
              </Card>
              
              <Card className="bg-pink-500/10 border-pink-500/20">
                <CardHeader className="p-4">
                  <CardTitle className="text-lg flex items-center gap-2">
                    <Trophy className="h-5 w-5 text-pink-500" />
                    Current Streak
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-4 pt-0">
                  <div className="text-3xl font-bold text-pink-500">{practiceStats.streak}</div>
                  <Progress value={practiceStats.streak * 10} className="mt-2" />
                </CardContent>
              </Card>
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle className="text-xl font-bold flex items-center gap-2">
              <BookOpen className="h-5 w-5 text-orange-500" />
              Chapter-wise Practice
            </CardTitle>
            <CardDescription>
              Select a chapter to practice previous year questions
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex gap-4">
                <Select value={selectedChapter} onValueChange={(value) => {
                  setSelectedChapter(value);
                  setCurrentQuestionIndex(0);
                  setSelectedAnswer(null);
                  setShowExplanation(false);
                }} className="flex-1">
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a chapter" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableChapters.length > 0 ? (
                      availableChapters.map((chapter) => (
                        <SelectItem key={chapter} value={chapter}>
                          {chapter}
                        </SelectItem>
                      ))
                    ) : (
                      <SelectItem value="no-questions" disabled>
                        Questions coming soon for {selectedExam}
                      </SelectItem>
                    )}
                  </SelectContent>
                </Select>
              </div>

              {selectedChapter && currentQuestion ? (
                <AnimatePresence mode="wait">
                  <motion.div
                    key={currentQuestionIndex}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="space-y-6"
                  >
                    <div className="flex justify-between items-center">
                      <Badge variant="outline" className="bg-orange-500/10 text-orange-500 border-orange-500/20">
                        {selectedExam} {currentQuestion.year}
                      </Badge>
                      <Badge variant="outline">
                        Question {currentQuestionIndex + 1}/{currentChapter.questions.length}
                      </Badge>
                    </div>
                    
                    <div className="p-6 rounded-lg bg-card border">
                      <p className="text-lg font-medium mb-6">{currentQuestion.question}</p>
                      
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                        {currentQuestion.options.map((option, index) => (
                          <Button
                            key={index}
                            variant={selectedAnswer === null ? "outline" : 
                              selectedAnswer === index ? 
                                (index === currentQuestion.correct ? "default" : "destructive") :
                                index === currentQuestion.correct ? "default" : "outline"}
                            className={`justify-start text-left h-auto py-3 px-4 ${
                              selectedAnswer !== null && "cursor-default"
                            }`}
                            onClick={() => {
                              if (selectedAnswer === null) {
                                handleAnswerSubmit(index);
                              }
                            }}
                            disabled={selectedAnswer !== null}
                          >
                            <div className="flex items-center gap-2">
                              {selectedAnswer !== null && index === currentQuestion.correct && (
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              )}
                              {selectedAnswer === index && index !== currentQuestion.correct && (
                                <XCircle className="h-4 w-4 text-red-500" />
                              )}
                              <span>{option}</span>
                            </div>
                          </Button>
                        ))}
                      </div>

                      {showExplanation && (
                        <motion.div
                          initial={{ opacity: 0, height: 0 }}
                          animate={{ opacity: 1, height: "auto" }}
                          className="mt-6 p-4 rounded-lg bg-muted"
                        >
                          <h4 className="font-semibold mb-2">Explanation:</h4>
                          <p>{currentQuestion.explanation}</p>
                        </motion.div>
                      )}

                      {selectedAnswer !== null && currentQuestionIndex < currentChapter.questions.length - 1 && (
                        <motion.div
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          className="mt-6 flex justify-end"
                        >
                          <Button onClick={nextQuestion}>Next Question</Button>
                        </motion.div>
                      )}
                    </div>
                  </motion.div>
                </AnimatePresence>
              ) : availableChapters.length === 0 ? (
                <div className="text-center py-12">
                  <BookOpen className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                  <h3 className="text-lg font-semibold mb-2">Questions Coming Soon</h3>
                  <p className="text-muted-foreground">
                    We're working on adding practice questions for {selectedExam}. Check back soon!
                  </p>
                </div>
              ) : null}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}