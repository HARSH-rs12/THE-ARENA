import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Book, FileText, Search, Download, AlertCircle, RefreshCcw, ExternalLink } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { supabase, testConnection } from '@/lib/supabase';

interface StudyMaterial {
  id: string;
  title: string;
  author: string;
  category: string;
  url: string;
  type: 'book' | 'notes' | 'mock';
  description: string;
  rating: number;
  downloads: number;
  created_at: string;
  exam: string;
}

interface BooksProps {
  selectedExam: string;
}

// Fallback data when Supabase is not connected
const fallbackMaterials: { [exam: string]: StudyMaterial[] } = {
  'JEE Main': [
    {
      id: '1',
      title: 'Concepts of Physics Vol 1',
      author: 'HC Verma',
      category: 'Physics',
      url: 'https://drive.google.com/file/d/1PJqzHwqwBvuYJ9KhIpnZvnDyIh1jI8F9/view',
      type: 'book',
      description: 'A comprehensive guide covering fundamental physics concepts with detailed explanations and solved examples.',
      rating: 4.8,
      downloads: 15000,
      created_at: '2024-01-01',
      exam: 'JEE Main'
    },
    {
      id: '2',
      title: 'Advanced Problems in Physical Chemistry',
      author: 'MS Chauhan',
      category: 'Chemistry',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Comprehensive collection of advanced chemistry problems with detailed solutions.',
      rating: 4.6,
      downloads: 13000,
      created_at: '2024-01-01',
      exam: 'JEE Main'
    },
    {
      id: '3',
      title: 'JEE Main Mock Test Series 2024',
      author: 'Allen Institute',
      category: 'Mock Tests',
      url: 'https://www.allen.ac.in/jee-main-mock-test',
      type: 'mock',
      description: 'Comprehensive mock test series with detailed analysis and performance tracking.',
      rating: 4.7,
      downloads: 25000,
      created_at: '2024-01-01',
      exam: 'JEE Main'
    }
  ],
  'UPSC CSE': [
    {
      id: '4',
      title: 'Indian Polity',
      author: 'M. Laxmikanth',
      category: 'Polity',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Comprehensive guide to Indian polity and governance.',
      rating: 4.9,
      downloads: 50000,
      created_at: '2024-01-01',
      exam: 'UPSC CSE'
    },
    {
      id: '5',
      title: 'Indian Economy',
      author: 'Ramesh Singh',
      category: 'Economics',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Complete coverage of Indian economy for UPSC preparation.',
      rating: 4.8,
      downloads: 45000,
      created_at: '2024-01-01',
      exam: 'UPSC CSE'
    },
    {
      id: '6',
      title: 'UPSC Prelims Mock Tests',
      author: 'Vision IAS',
      category: 'Mock Tests',
      url: 'https://www.visionias.in/upsc-prelims-mock-tests',
      type: 'mock',
      description: 'High-quality prelims mock tests with detailed explanations.',
      rating: 4.8,
      downloads: 60000,
      created_at: '2024-01-01',
      exam: 'UPSC CSE'
    }
  ],
  'SSC CGL': [
    {
      id: '7',
      title: 'SSC CGL Quantitative Aptitude',
      author: 'Kiran Publications',
      category: 'Mathematics',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Complete quantitative aptitude guide for SSC CGL.',
      rating: 4.5,
      downloads: 30000,
      created_at: '2024-01-01',
      exam: 'SSC CGL'
    },
    {
      id: '8',
      title: 'SSC CGL Mock Tests',
      author: 'Adda247',
      category: 'Mock Tests',
      url: 'https://www.adda247.com/ssc-cgl-mock-tests',
      type: 'mock',
      description: 'Complete mock test series for all tiers of SSC CGL.',
      rating: 4.6,
      downloads: 40000,
      created_at: '2024-01-01',
      exam: 'SSC CGL'
    }
  ],
  'GATE': [
    {
      id: '9',
      title: 'GATE Computer Science',
      author: 'Made Easy Publications',
      category: 'Computer Science',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Complete GATE CS preparation with theory and practice questions.',
      rating: 4.6,
      downloads: 22000,
      created_at: '2024-01-01',
      exam: 'GATE'
    },
    {
      id: '10',
      title: 'GATE Mock Test Series',
      author: 'GATE Academy',
      category: 'Mock Tests',
      url: 'https://www.gateacademy.co.in/mock-tests',
      type: 'mock',
      description: 'Subject-wise and full-length mock tests for all GATE branches.',
      rating: 4.7,
      downloads: 30000,
      created_at: '2024-01-01',
      exam: 'GATE'
    }
  ],
  'IBPS PO': [
    {
      id: '11',
      title: 'IBPS PO Complete Guide',
      author: 'Arihant',
      category: 'Banking',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Comprehensive guide for IBPS PO examination.',
      rating: 4.5,
      downloads: 35000,
      created_at: '2024-01-01',
      exam: 'IBPS PO'
    },
    {
      id: '12',
      title: 'Banking Mock Tests',
      author: 'Testbook',
      category: 'Mock Tests',
      url: 'https://testbook.com/banking-mock-tests',
      type: 'mock',
      description: 'Comprehensive mock tests for all banking examinations.',
      rating: 4.6,
      downloads: 50000,
      created_at: '2024-01-01',
      exam: 'IBPS PO'
    }
  ],
  'NDA': [
    {
      id: '13',
      title: 'NDA Mathematics',
      author: 'Arihant Publications',
      category: 'Mathematics',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Complete mathematics guide for NDA examination.',
      rating: 4.5,
      downloads: 18000,
      created_at: '2024-01-01',
      exam: 'NDA'
    },
    {
      id: '14',
      title: 'NDA Mock Test Series',
      author: 'Major Kalshi Classes',
      category: 'Mock Tests',
      url: 'https://www.majorkalshiclasses.com/nda-mock-tests',
      type: 'mock',
      description: 'Complete mock test series with SSB interview preparation.',
      rating: 4.6,
      downloads: 20000,
      created_at: '2024-01-01',
      exam: 'NDA'
    }
  ],
  'UGC NET': [
    {
      id: '15',
      title: 'UGC NET Paper 1',
      author: 'Trueman Publications',
      category: 'Teaching Aptitude',
      url: 'https://drive.google.com/file/d/1PK8MQ9H9R7H9H9H9H9H9H9H9H9H9H9H/view',
      type: 'book',
      description: 'Complete guide for UGC NET Paper 1 preparation.',
      rating: 4.5,
      downloads: 28000,
      created_at: '2024-01-01',
      exam: 'UGC NET'
    },
    {
      id: '16',
      title: 'Teaching Mock Tests',
      author: 'Gradeup',
      category: 'Mock Tests',
      url: 'https://gradeup.co/teaching-mock-tests',
      type: 'mock',
      description: 'Mock tests for all teaching examinations including CTET, UGC NET.',
      rating: 4.5,
      downloads: 35000,
      created_at: '2024-01-01',
      exam: 'UGC NET'
    }
  ]
};

export function Books({ selectedExam }: BooksProps) {
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [materials, setMaterials] = useState<StudyMaterial[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkConnection();
  }, [selectedExam]);

  async function checkConnection() {
    const connected = await testConnection();
    setIsConnected(connected);
    if (connected) {
      fetchMaterials();
    } else {
      // Use fallback data
      const fallbackData = fallbackMaterials[selectedExam] || [];
      setMaterials(fallbackData);
      setLoading(false);
      if (fallbackData.length === 0) {
        setError(`Study materials for ${selectedExam} will be available soon. We're working on adding comprehensive resources!`);
      }
    }
  }

  async function fetchMaterials() {
    if (!supabase) {
      setError('Supabase connection not available');
      setLoading(false);
      return;
    }

    try {
      setLoading(true);
      setError(null);
      
      const { data, error } = await supabase
        .from('study_materials')
        .select('*')
        .eq('exam', selectedExam)
        .order('downloads', { ascending: false });

      if (error) throw error;

      if (!data || data.length === 0) {
        // Use fallback data if no data in Supabase
        const fallbackData = fallbackMaterials[selectedExam] || [];
        setMaterials(fallbackData);
        if (fallbackData.length === 0) {
          setError(`Study materials for ${selectedExam} will be available soon. We're working on adding comprehensive resources!`);
        }
      } else {
        setMaterials(data);
      }
    } catch (err) {
      console.error('Error fetching materials:', err);
      // Use fallback data on error
      const fallbackData = fallbackMaterials[selectedExam] || [];
      setMaterials(fallbackData);
      if (fallbackData.length === 0) {
        setError(`Study materials for ${selectedExam} will be available soon. We're working on adding comprehensive resources!`);
      }
    } finally {
      setLoading(false);
    }
  }

  const filteredMaterials = materials
    .filter(material => 
      (selectedCategory === 'all' || material.category === selectedCategory) &&
      (selectedType === 'all' || material.type === selectedType) &&
      (searchQuery === '' || 
        material.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        material.author.toLowerCase().includes(searchQuery.toLowerCase()) ||
        material.description.toLowerCase().includes(searchQuery.toLowerCase()))
    );

  const handleDownload = async (material: StudyMaterial) => {
    try {
      toast({
        title: "Opening Resource",
        description: `${material.title} is being opened...`,
      });
      
      window.open(material.url, '_blank');
      
      // Update download count if Supabase is connected
      if (supabase && isConnected) {
        const { error } = await supabase
          .from('study_materials')
          .update({ downloads: material.downloads + 1 })
          .eq('id', material.id);

        if (!error) {
          setMaterials(prev => prev.map(m => 
            m.id === material.id ? { ...m, downloads: m.downloads + 1 } : m
          ));
        }
      }
    } catch (err) {
      console.error('Error opening resource:', err);
      toast({
        title: "Error",
        description: "Failed to open resource. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleRetry = () => {
    checkConnection();
  };

  if (loading) {
    return (
      <Card className="h-full">
        <CardHeader>
          <CardTitle className="text-2xl font-bold">Loading Study Materials...</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-center h-[400px]">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  const uniqueCategories = ['all', ...new Set(materials.map(m => m.category))];
  const uniqueTypes = ['all', 'book', 'notes', 'mock'];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'book': return <Book className="h-8 w-8 text-orange-500" />;
      case 'notes': return <FileText className="h-8 w-8 text-purple-500" />;
      case 'mock': return <ExternalLink className="h-8 w-8 text-green-500" />;
      default: return <Book className="h-8 w-8 text-orange-500" />;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'book': return 'text-orange-500 bg-orange-500/10 border-orange-500/20';
      case 'notes': return 'text-purple-500 bg-purple-500/10 border-purple-500/20';
      case 'mock': return 'text-green-500 bg-green-500/10 border-green-500/20';
      default: return 'text-orange-500 bg-orange-500/10 border-orange-500/20';
    }
  };

  return (
    <Card className="h-full">
      <CardHeader>
        <CardTitle className="text-2xl font-bold flex items-center gap-2">
          <Book className="h-6 w-6 text-orange-500" />
          Study Resources for {selectedExam}
        </CardTitle>
        <CardDescription>
          Access books, notes, and mock tests from top sources
        </CardDescription>
        
        <div className="flex flex-col gap-4 mt-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search materials..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
            />
          </div>
          
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex gap-2 flex-wrap">
              <span className="text-sm font-medium text-muted-foreground">Category:</span>
              {uniqueCategories.map((category) => (
                <motion.button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`px-3 py-1 rounded-full text-xs ${
                    selectedCategory === category
                      ? 'bg-orange-500 text-white'
                      : 'bg-muted hover:bg-orange-500/10'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {category}
                </motion.button>
              ))}
            </div>
            
            <div className="flex gap-2 flex-wrap">
              <span className="text-sm font-medium text-muted-foreground">Type:</span>
              {uniqueTypes.map((type) => (
                <motion.button
                  key={type}
                  onClick={() => setSelectedType(type)}
                  className={`px-3 py-1 rounded-full text-xs ${
                    selectedType === type
                      ? 'bg-purple-500 text-white'
                      : 'bg-muted hover:bg-purple-500/10'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  {type}
                </motion.button>
              ))}
            </div>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <Alert className="mb-4">
            <AlertCircle className="h-4 w-4" />
            <AlertTitle>Notice</AlertTitle>
            <AlertDescription className="flex flex-col gap-4">
              <p>{error}</p>
              {!isConnected && (
                <Button onClick={handleRetry} variant="outline" className="w-fit">
                  <RefreshCcw className="h-4 w-4 mr-2" />
                  Retry Connection
                </Button>
              )}
            </AlertDescription>
          </Alert>
        )}
        
        <ScrollArea className="h-[600px] pr-4">
          {filteredMaterials.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">No materials found</h3>
              <p className="text-muted-foreground">
                {materials.length === 0 
                  ? `Study materials for ${selectedExam} will be available soon!`
                  : "Try adjusting your search or filters"
                }
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredMaterials.map((material, index) => (
                <motion.div
                  key={material.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Card className={`hover:bg-muted/50 transition-colors ${getTypeColor(material.type)} border`}>
                    <CardContent className="p-4">
                      <div className="flex items-start gap-3">
                        <div className="mt-1 flex-shrink-0">
                          {getTypeIcon(material.type)}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-semibold">{material.title}</h3>
                          <p className="text-sm text-muted-foreground">
                            {material.author}
                          </p>
                          <p className="text-sm mt-2">{material.description}</p>
                          <div className="flex items-center gap-2 mt-3 flex-wrap">
                            <span className="text-xs px-2 py-1 rounded-full bg-orange-500/10 text-orange-500">
                              {material.category}
                            </span>
                            <span className={`text-xs px-2 py-1 rounded-full ${getTypeColor(material.type)}`}>
                              {material.type === 'book' ? 'Book' : material.type === 'notes' ? 'Notes' : 'Mock Test'}
                            </span>
                            <span className="text-xs px-2 py-1 rounded-full bg-green-500/10 text-green-500">
                              ★ {material.rating}
                            </span>
                            <span className="text-xs px-2 py-1 rounded-full bg-blue-500/10 text-blue-500">
                              {material.downloads.toLocaleString()} downloads
                            </span>
                          </div>
                          <Button
                            variant="ghost"
                            size="sm"
                            className="w-full mt-3"
                            onClick={() => handleDownload(material)}
                          >
                            {material.type === 'mock' ? (
                              <>
                                <ExternalLink className="h-4 w-4 mr-2" />
                                Take Test
                              </>
                            ) : (
                              <>
                                <Download className="h-4 w-4 mr-2" />
                                Access
                              </>
                            )}
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </div>
          )}
        </ScrollArea>
      </CardContent>
    </Card>
  );
}