import { useState, useEffect } from 'react';
import { syllabus as allSyllabi } from '@/data/syllabus';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { useLocalStorage } from '@/hooks/use-local-storage';
import { ArrowRight, CheckCircle2, AlertCircle } from 'lucide-react';

interface SyllabusTrackerProps {
  selectedExam: string;
  limit?: number;
  showViewAll?: boolean;
  onViewAll?: () => void;
}

export function SyllabusTracker({ 
  selectedExam,
  limit, 
  showViewAll = false,
  onViewAll 
}: SyllabusTrackerProps) {
  const [progress, setProgress] = useLocalStorage('arena-syllabus-progress', {});
  const [overallProgress, setOverallProgress] = useState(0);
  
  const examSyllabus = allSyllabi[selectedExam] || [];
  
  // If no syllabus data is available, show a message
  if (examSyllabus.length === 0) {
    return (
      <div className="rounded-lg border border-border bg-card p-6">
        <div className="flex items-center gap-2 text-yellow-600">
          <AlertCircle className="h-5 w-5" />
          <h3 className="text-lg font-semibold">No Syllabus Available</h3>
        </div>
        <p className="mt-2 text-sm text-muted-foreground">
          The syllabus for {selectedExam} is not available. Please select a different exam or contact support if you believe this is an error.
        </p>
      </div>
    );
  }

  const displayedSyllabus = limit ? examSyllabus.slice(0, limit) : examSyllabus;

  const toggleCheckbox = (chapter: string, index: number) => {
    const key = `${selectedExam}-${chapter}-${index}`;
    const newProgress = {
      ...progress,
      [key]: !progress[key]
    };
    
    setProgress(newProgress);
  };
  
  // Calculate overall progress percentage
  useEffect(() => {
    const totalCheckboxes = examSyllabus.length * 7; // 7 columns per chapter
    let checked = 0;
    
    for (const key in progress) {
      if (key.startsWith(selectedExam) && progress[key]) checked++;
    }
    
    setOverallProgress(totalCheckboxes > 0 ? (checked / totalCheckboxes) * 100 : 0);
  }, [progress, examSyllabus.length, selectedExam]);

  // Get the completion status for a chapter
  const getChapterProgress = (chapter: string) => {
    let completed = 0;
    for (let i = 0; i < 7; i++) {
      if (progress[`${selectedExam}-${chapter}-${i}`]) completed++;
    }
    return (completed / 7) * 100;
  };

  return (
    <div className="rounded-lg border border-border bg-card">
      <div className="p-6 pb-3">
        <div className="flex justify-between items-center mb-4">
          <div>
            <h3 className="text-xl font-bold inline-flex items-center gap-2">
              {selectedExam} Syllabus Tracker
              <Badge variant="outline" className="ml-2">
                {Math.round(overallProgress)}% Complete
              </Badge>
            </h3>
            <p className="text-sm text-muted-foreground mt-1">
              Track your progress through the entire {selectedExam} syllabus
            </p>
          </div>
          {showViewAll && (
            <Button variant="outline" size="sm" onClick={onViewAll} className="gap-1">
              View All <ArrowRight className="h-4 w-4" />
            </Button>
          )}
        </div>
        
        <Progress value={overallProgress} className="h-2 mb-6" />
      </div>
      
      <div className="overflow-x-auto">
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-t border-border bg-muted/50">
              <th className="text-left px-6 py-3 text-sm font-medium">Chapter</th>
              <th className="px-3 py-3 text-sm font-medium">Theory</th>
              <th className="px-3 py-3 text-sm font-medium">Theory Revised</th>
              <th className="px-3 py-3 text-sm font-medium">Chapter Test</th>
              <th className="px-3 py-3 text-sm font-medium">Book Solved</th>
              <th className="px-3 py-3 text-sm font-medium">Revision 1</th>
              <th className="px-3 py-3 text-sm font-medium">Revision 2</th>
              <th className="px-3 py-3 text-sm font-medium">Revision 3</th>
              <th className="px-6 py-3 text-sm font-medium">Progress</th>
            </tr>
          </thead>
          <tbody>
            {displayedSyllabus.map((chapter, i) => (
              <tr 
                key={i} 
                className="border-t border-border hover:bg-muted/50 transition-colors"
              >
                <td className="px-6 py-3 text-sm font-medium">{chapter}</td>
                {[...Array(7)].map((_, j) => (
                  <td key={j} className="px-4 py-3 text-center">
                    <div 
                      className={`
                        h-5 w-5 rounded-sm border cursor-pointer mx-auto
                        flex items-center justify-center
                        ${progress[`${selectedExam}-${chapter}-${j}`] 
                          ? 'bg-orange-500 border-orange-500 text-white'
                          : 'border-border hover:border-orange-500/50 hover:bg-orange-500/10'}
                      `}
                      onClick={() => toggleCheckbox(chapter, j)}
                    >
                      {progress[`${selectedExam}-${chapter}-${j}`] && <CheckCircle2 className="h-4 w-4" />}
                    </div>
                  </td>
                ))}
                <td className="px-6 py-3">
                  <div className="w-16">
                    <Progress 
                      value={getChapterProgress(chapter)} 
                      className="h-2 w-full" 
                    />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}