import { useState, useEffect } from 'react';
import { ArenaIntro } from './ArenaIntro';
import { MainArena } from './MainArena';
import { ExamSelector } from './ExamSelector';

export function ArenaApp() {
  const [showIntro, setShowIntro] = useState(true);
  const [selectedExam, setSelectedExam] = useState<string | null>(null);

  // Reset intro state when component unmounts and remounts
  useEffect(() => {
    setShowIntro(true);
    const timer = setTimeout(() => {
      setShowIntro(false);
    }, 10000); // 10 sec intro
    
    return () => clearTimeout(timer);
  }, []);

  const handleSkipIntro = () => {
    setShowIntro(false);
  };

  const handleBackToExamSelector = () => {
    setSelectedExam(null);
  };

  if (!selectedExam && !showIntro) {
    return <ExamSelector onExamSelect={setSelectedExam} />;
  }

  return (
    <div className="min-h-screen bg-background text-foreground overflow-hidden">
      {showIntro ? (
        <ArenaIntro onSkip={handleSkipIntro} />
      ) : (
        <MainArena selectedExam={selectedExam!} onBack={handleBackToExamSelector} />
      )}
    </div>
  );
}