import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { examCategories } from '@/data/syllabus';
import { GraduationCap, Shield, Building2, Landmark, School } from 'lucide-react';

const categoryIcons = {
  engineering: GraduationCap,
  defense: Shield,
  civilServices: Building2,
  banking: Landmark,
  teaching: School,
};

interface ExamSelectorProps {
  onExamSelect: (exam: string) => void;
}

export function ExamSelector({ onExamSelect }: ExamSelectorProps) {
  return (
    <div className="container mx-auto py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-12"
      >
        <h1 className="text-4xl font-bold mb-4">Welcome to The Arena</h1>
        <p className="text-xl text-muted-foreground">Choose your battlefield</p>
      </motion.div>

      <ScrollArea className="h-[calc(100vh-200px)]">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Object.entries(examCategories).map(([key, category], index) => {
            const Icon = categoryIcons[key as keyof typeof categoryIcons];
            
            return (
              <motion.div
                key={key}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
              >
                <Card className="h-full">
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Icon className="h-6 w-6 text-orange-500" />
                      {category.name}
                    </CardTitle>
                    <CardDescription>
                      Select your target examination
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="grid gap-2">
                      {category.exams.map((exam) => (
                        <motion.button
                          key={exam}
                          onClick={() => onExamSelect(exam)}
                          className="w-full text-left px-4 py-3 rounded-lg bg-muted/50 hover:bg-orange-500/10 transition-colors"
                          whileHover={{ scale: 1.02 }}
                          whileTap={{ scale: 0.98 }}
                        >
                          {exam}
                        </motion.button>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>
      </ScrollArea>
    </div>
  );
}