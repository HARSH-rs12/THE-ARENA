import { Sword, ArrowLeft, Globe } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { motion } from 'framer-motion';
import { useState } from 'react';
import { examCategories } from '@/data/syllabus';

interface HeaderProps {
  selectedExam: string;
  onBack?: () => void;
  showBackButton?: boolean;
}

export function Header({ selectedExam, onBack, showBackButton = false }: HeaderProps) {
  const [profileImage, setProfileImage] = useState('');
  const [targetExam, setTargetExam] = useState(selectedExam);
  const [userName, setUserName] = useState('Warrior');
  const [userEmail, setUserEmail] = useState('user@example.com');
  const [language, setLanguage] = useState('English');

  return (
    <header className="border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container mx-auto h-16 flex items-center justify-between px-4">
        <div className="flex items-center gap-4">
          {showBackButton && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onBack}
              className="hover:bg-orange-500/10"
            >
              <ArrowLeft className="h-5 w-5" />
            </Button>
          )}
          <motion.div
            initial={{ rotate: -45 }}
            animate={{ rotate: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Sword className="h-6 w-6 text-orange-500" />
          </motion.div>
          <div>
            <span className="font-bold text-xl tracking-tight">THE ARENA</span>
            <span className="text-sm text-muted-foreground ml-2">
              {selectedExam}
            </span>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center gap-4">
            <motion.div 
              className="flex items-center gap-1 bg-muted/50 px-3 py-1 rounded-full"
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
            >
              <span className="text-orange-500 font-semibold">250</span>
              <span className="text-xs text-muted-foreground">XP</span>
            </motion.div>
            
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-32">
                <Globe className="h-4 w-4 mr-2" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="English">English</SelectItem>
                <SelectItem value="Hindi">हिंदी</SelectItem>
                <SelectItem value="Bengali">বাংলা</SelectItem>
                <SelectItem value="Tamil">தமிழ்</SelectItem>
                <SelectItem value="Telugu">తెలుగు</SelectItem>
                <SelectItem value="Marathi">मराठी</SelectItem>
                <SelectItem value="Gujarati">ગુજરાતી</SelectItem>
                <SelectItem value="Kannada">ಕನ್ನಡ</SelectItem>
                <SelectItem value="Malayalam">മലയാളം</SelectItem>
                <SelectItem value="Punjabi">ਪੰਜਾਬੀ</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <Dialog>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="relative h-8 w-8 rounded-full">
                  <Avatar className="h-8 w-8">
                    {profileImage ? (
                      <AvatarImage src={profileImage} alt={userName} />
                    ) : (
                      <AvatarFallback className="bg-orange-500/20 text-orange-500">
                        {userName.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    )}
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent className="w-56" align="end" forceMount>
                <DropdownMenuLabel className="font-normal">
                  <div className="flex flex-col space-y-1">
                    <p className="text-sm font-medium leading-none">{userName}</p>
                    <p className="text-xs leading-none text-muted-foreground">
                      {userEmail}
                    </p>
                  </div>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DialogTrigger asChild>
                  <DropdownMenuItem>
                    Edit Profile
                  </DropdownMenuItem>
                </DialogTrigger>
                <DropdownMenuItem>
                  Settings
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  Log out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Profile</DialogTitle>
                <DialogDescription>
                  Update your profile information
                </DialogDescription>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label htmlFor="name">Name</Label>
                  <Input
                    id="name"
                    value={userName}
                    onChange={(e) => setUserName(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <Input
                    id="email"
                    type="email"
                    value={userEmail}
                    onChange={(e) => setUserEmail(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="target-exam">Target Exam</Label>
                  <Select value={targetExam} onValueChange={setTargetExam}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select your target exam" />
                    </SelectTrigger>
                    <SelectContent>
                      {Object.entries(examCategories).map(([category, data]) => (
                        <div key={category}>
                          <Label className="px-2 py-1.5 text-sm font-semibold text-muted-foreground">
                            {data.name}
                          </Label>
                          {data.exams.map((exam) => (
                            <SelectItem key={exam} value={exam}>
                              {exam}
                            </SelectItem>
                          ))}
                        </div>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="avatar">Profile Picture URL</Label>
                  <Input
                    id="avatar"
                    type="url"
                    placeholder="https://example.com/avatar.jpg"
                    value={profileImage}
                    onChange={(e) => setProfileImage(e.target.value)}
                  />
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </header>
  );
}