import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { HelpCircle, Search, ExternalLink, MessageCircle, Clock, CheckCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useToast } from '@/hooks/use-toast';

interface Doubt {
  id: string;
  question: string;
  subject: string;
  topic: string;
  status: 'pending' | 'resolved';
  timestamp: Date;
  googleSearchUrl?: string;
}

interface DoubtSectionProps {
  selectedExam: string;
}

export function DoubtSection({ selectedExam }: DoubtSectionProps) {
  const [doubtText, setDoubtText] = useState('');
  const [subject, setSubject] = useState('');
  const [topic, setTopic] = useState('');
  const [doubts, setDoubts] = useState<Doubt[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const { toast } = useToast();

  const handleSubmitDoubt = () => {
    if (!doubtText.trim()) {
      toast({
        title: "Error",
        description: "Please enter your doubt",
        variant: "destructive",
      });
      return;
    }

    const newDoubt: Doubt = {
      id: Date.now().toString(),
      question: doubtText,
      subject: subject || 'General',
      topic: topic || 'General',
      status: 'pending',
      timestamp: new Date(),
      googleSearchUrl: `https://www.google.com/search?q=${encodeURIComponent(doubtText + ' ' + selectedExam)}`
    };

    setDoubts([newDoubt, ...doubts]);
    setDoubtText('');
    setSubject('');
    setTopic('');

    toast({
      title: "Doubt Submitted!",
      description: "Your doubt has been recorded. Click 'Search Solution' to find answers.",
    });
  };

  const handleSearchSolution = (doubt: Doubt) => {
    if (doubt.googleSearchUrl) {
      window.open(doubt.googleSearchUrl, '_blank');
      
      // Mark as resolved after opening Google search
      setDoubts(doubts.map(d => 
        d.id === doubt.id ? { ...d, status: 'resolved' } : d
      ));

      toast({
        title: "Searching for Solution",
        description: "Opening Google search with your doubt. Mark as resolved when you find the answer!",
      });
    }
  };

  const filteredDoubts = doubts.filter(doubt =>
    doubt.question.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doubt.subject.toLowerCase().includes(searchQuery.toLowerCase()) ||
    doubt.topic.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <Card className="bg-gradient-to-br from-blue-500/10 via-purple-500/10 to-pink-500/10">
        <CardHeader>
          <CardTitle className="text-2xl font-bold flex items-center gap-3">
            <HelpCircle className="h-8 w-8 text-blue-500" />
            Doubt Resolution Center
          </CardTitle>
          <CardDescription className="text-lg">
            Ask your doubts and get instant help through AI-powered Google search
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium mb-2 block">Your Doubt</label>
                <Textarea
                  placeholder="Describe your doubt in detail..."
                  value={doubtText}
                  onChange={(e) => setDoubtText(e.target.value)}
                  className="min-h-[100px]"
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium mb-2 block">Subject</label>
                  <Input
                    placeholder="e.g., Physics, Math"
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium mb-2 block">Topic</label>
                  <Input
                    placeholder="e.g., Mechanics, Algebra"
                    value={topic}
                    onChange={(e) => setTopic(e.target.value)}
                  />
                </div>
              </div>
              <Button onClick={handleSubmitDoubt} className="w-full">
                <MessageCircle className="h-4 w-4 mr-2" />
                Submit Doubt
              </Button>
            </div>
            
            <div className="bg-muted/50 rounded-lg p-4">
              <h3 className="font-semibold mb-3 flex items-center gap-2">
                <Search className="h-5 w-5 text-blue-500" />
                How it works
              </h3>
              <div className="space-y-2 text-sm text-muted-foreground">
                <p>1. Submit your doubt with subject and topic details</p>
                <p>2. Click "Search Solution" to open Google with optimized search</p>
                <p>3. Find the best explanations from top educational websites</p>
                <p>4. Mark as resolved when you understand the concept</p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Your Doubts History</span>
            <Badge variant="outline">
              {doubts.length} Total Doubts
            </Badge>
          </CardTitle>
          <div className="flex gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search your doubts..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <ScrollArea className="h-[400px]">
            {filteredDoubts.length === 0 ? (
              <div className="text-center py-12">
                <HelpCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <h3 className="text-lg font-semibold mb-2">No doubts yet</h3>
                <p className="text-muted-foreground">
                  Submit your first doubt to get started with personalized help
                </p>
              </div>
            ) : (
              <div className="space-y-4">
                <AnimatePresence>
                  {filteredDoubts.map((doubt, index) => (
                    <motion.div
                      key={doubt.id}
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ delay: index * 0.1 }}
                    >
                      <Card className="hover:bg-muted/50 transition-colors">
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-2 mb-2">
                                <Badge variant={doubt.status === 'resolved' ? 'default' : 'secondary'}>
                                  {doubt.status === 'resolved' ? (
                                    <CheckCircle className="h-3 w-3 mr-1" />
                                  ) : (
                                    <Clock className="h-3 w-3 mr-1" />
                                  )}
                                  {doubt.status}
                                </Badge>
                                <Badge variant="outline">{doubt.subject}</Badge>
                                <Badge variant="outline">{doubt.topic}</Badge>
                              </div>
                              <p className="font-medium mb-2">{doubt.question}</p>
                              <p className="text-xs text-muted-foreground">
                                {doubt.timestamp.toLocaleString()}
                              </p>
                            </div>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleSearchSolution(doubt)}
                              className="flex-shrink-0"
                            >
                              <ExternalLink className="h-4 w-4 mr-2" />
                              Search Solution
                            </Button>
                          </div>
                        </CardContent>
                      </Card>
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </ScrollArea>
        </CardContent>
      </Card>
    </div>
  );
}