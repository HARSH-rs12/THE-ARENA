import { createClient } from '@supabase/supabase-js';
import type { ExamProfile, Challenge, StudySession, TestResult, StudyGroup } from '@/types/exam';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

// Create a dummy client if credentials are missing
export const supabase = supabaseUrl && supabaseAnonKey 
  ? createClient(supabaseUrl, supabaseAnonKey)
  : null;

// Test connection
export async function testConnection() {
  if (!supabase) return false;
  
  try {
    const { error } = await supabase.from('study_materials').select('count');
    if (error) throw error;
    return true;
  } catch (err) {
    console.error('Failed to connect to Supabase:', err);
    return false;
  }
}

// Profile Management
export async function createProfile(profile: ExamProfile) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('user_profiles')
    .insert([profile])
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

export async function updateProfile(userId: string, updates: Partial<ExamProfile>) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('user_profiles')
    .update(updates)
    .eq('user_id', userId)
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

// Challenges
export async function fetchChallenges(userId: string) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('challenges')
    .select('*')
    .eq('user_id', userId);
    
  if (error) throw error;
  return data as Challenge[];
}

// Study Sessions
export async function recordStudySession(session: StudySession) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('study_sessions')
    .insert([session])
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

// Test Results
export async function saveTestResult(result: TestResult) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('test_results')
    .insert([result])
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

// Study Groups
export async function createStudyGroup(group: StudyGroup) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('study_groups')
    .insert([group])
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

export async function joinStudyGroup(groupId: string, userId: string) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data: group, error: fetchError } = await supabase
    .from('study_groups')
    .select('members')
    .eq('id', groupId)
    .single();
    
  if (fetchError) throw fetchError;
  
  const updatedMembers = [...group.members, userId];
  
  const { data, error } = await supabase
    .from('study_groups')
    .update({ members: updatedMembers })
    .eq('id', groupId)
    .select()
    .single();
    
  if (error) throw error;
  return data;
}

// Leaderboard
export async function fetchLeaderboard(examType: string) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('user_profiles')
    .select('id, missionName, avatar, stats')
    .eq('examType', examType)
    .order('stats->xp', { ascending: false })
    .limit(100);
    
  if (error) throw error;
  return data;
}

// Current Affairs
export async function fetchCurrentAffairs(category: string) {
  if (!supabase) throw new Error('Supabase client not initialized');
  
  const { data, error } = await supabase
    .from('current_affairs')
    .select('*')
    .eq('category', category)
    .order('date', { ascending: false })
    .limit(50);
    
  if (error) throw error;
  return data;
}